import { Shape, ShapeConfig } from '../Shape';
import { GetSet, IRect } from '../types';
import * as PIXI from "pixi.js";
export interface ImageConfig extends ShapeConfig {
    image: CanvasImageSource | undefined;
    crop?: IRect;
    cornerRadius?: number | number[];
}
export declare class Image extends Shape<ImageConfig> {
    private _loadListener;
    _object: PIXI.Sprite;
    constructor(attrs: ImageConfig);
    _setImageLoad(): void;
    _removeImageLoad(image: any): void;
    destroy(): this;
    _sceneFunc(graphics: PIXI.Graphics): void;
    getWidth(): any;
    getHeight(): any;
    static fromURL(url: string, callback: (img: Image) => void, onError?: OnErrorEventHandler): void;
    image: GetSet<CanvasImageSource | undefined, this>;
    crop: GetSet<IRect, this>;
    cropX: GetSet<number, this>;
    cropY: GetSet<number, this>;
    cropWidth: GetSet<number, this>;
    cropHeight: GetSet<number, this>;
    cornerRadius: GetSet<number | number[], this>;
}
