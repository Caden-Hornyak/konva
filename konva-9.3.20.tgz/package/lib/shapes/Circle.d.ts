import { Shape, ShapeConfig } from '../Shape';
import { GetSet } from '../types';
import * as PIXI from "pixi.js";
export interface CircleConfig extends ShapeConfig {
    radius?: number;
}
export declare class Circle extends Shape<CircleConfig> {
    _object: PIXI.Graphics;
    constructor(config?: CircleConfig);
    getWidth(): number;
    getHeight(): number;
    setWidth(width: number): void;
    setHeight(height: number): void;
    radius: GetSet<number, this>;
}
