import { Shape, ShapeConfig } from '../Shape';
import { GetSet } from '../types';
import * as PIXI from "pixi.js";
export interface RectConfig extends ShapeConfig {
    cornerRadius?: number | number[];
}
export declare class Rect extends Shape<RectConfig> {
    _object: PIXI.NineSlicePlane;
    constructor(config?: RectConfig);
    cornerRadius: GetSet<number | number[], this>;
}
