import { Shape, ShapeConfig } from '../Shape';
import { GetSet, Vector2d } from '../types';
import * as PIXI from "pixi.js";
export interface RegularPolygonConfig extends ShapeConfig {
    sides: number;
    radius: number;
    cornerRadius?: number | number[];
}
export declare class RegularPolygon extends Shape<RegularPolygonConfig> {
    _object: PIXI.Sprite;
    constructor(config?: RegularPolygonConfig);
    _getPoints(): Vector2d[];
    getSelfRect(): {
        x: number;
        y: number;
        width: number;
        height: number;
    };
    getWidth(): number;
    getHeight(): number;
    setWidth(width: number): void;
    setHeight(height: number): void;
    radius: GetSet<number, this>;
    sides: GetSet<number, this>;
    cornerRadius: GetSet<number | number[], this>;
}
