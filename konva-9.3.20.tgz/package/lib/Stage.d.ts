import { Container, ContainerConfig } from './Container';
import { GetSet, Vector2d } from './types';
import { Shape } from './Shape';
import { Layer } from './Layer';
import * as PIXI from "pixi.js";
export interface StageConfig extends ContainerConfig {
    container?: HTMLDivElement | string;
}
export declare const stages: Stage[];
export declare class Stage extends Container<Layer> {
    content: HTMLDivElement;
    application: PIXI.Application;
    pointerPos: Vector2d | null;
    _pointerPositions: (Vector2d & {
        id?: number;
    })[];
    _changedPointerPositions: (Vector2d & {
        id: number;
    })[];
    constructor(config: StageConfig);
    static create(config: any): Promise<Stage>;
    _validateAdd(child: any): void;
    _checkVisibility(): void;
    setContainer(container: any): this;
    shouldDrawHit(): boolean;
    clone(obj?: any): this;
    destroy(): this;
    getPointerPosition(): Vector2d | null;
    _getPointerById(id?: number): (Vector2d & {
        id?: number;
    }) | undefined;
    getPointersPositions(): (Vector2d & {
        id?: number;
    })[];
    getStage(): this;
    add(layer: Layer, ...rest: any[]): this;
    getParent(): null;
    getLayer(): null;
    getLayers(): Record<string, Layer[]>;
    _bindContentEvents(): void;
    _getTargetShape(evenType: any): Shape<import("./Shape").ShapeConfig> | null;
    setPointersPositions(evt: any): void;
    _setPointerPosition(evt: any): void;
    _getContentPosition(): {
        top: number;
        left: number;
        scaleX: number;
        scaleY: number;
    };
    container: GetSet<HTMLDivElement, this>;
}
