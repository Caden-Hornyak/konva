import { Node, NodeConfig } from './Node';
import { GetSet, IRect } from './types';
import * as PIXI from "pixi.js";
export type ClipFuncOutput = void | [Path2D | CanvasFillRule] | [Path2D, CanvasFillRule];
export interface ContainerConfig extends NodeConfig {
    clearBeforeDraw?: boolean;
    clipX?: number;
    clipY?: number;
    clipWidth?: number;
    clipHeight?: number;
}
export declare abstract class Container<ChildType extends Node = Node> extends Node<ContainerConfig> {
    children: Record<string, Record<string, ChildType>>;
    _object: PIXI.Container;
    constructor(config?: ContainerConfig);
    getChildren(filterFunc?: (item: Node) => boolean): Record<string, Record<string, ChildType>>;
    hasChildren(): boolean;
    removeChildren(): this;
    destroyChildren(): this;
    abstract _validateAdd(node: Node): void;
    add(...children: ChildType[]): this;
    destroy(): this;
    find<ChildNode extends Node>(selector: any): Array<ChildNode>;
    findOne<ChildNode extends Node = Node>(selector: string): ChildNode | undefined;
    toObject(): {
        attrs: any;
        className: string;
        children?: Array<any>;
    };
    isAncestorOf(node: Node): boolean;
    getClientRect(config?: {
        skipTransform?: boolean;
        skipShadow?: boolean;
        skipStroke?: boolean;
        relativeTo?: Container<Node>;
    }): IRect;
    clip: GetSet<IRect, this>;
    clipX: GetSet<number, this>;
    clipY: GetSet<number, this>;
    clipWidth: GetSet<number, this>;
    clipHeight: GetSet<number, this>;
    clipFunc: GetSet<(ctx: CanvasRenderingContext2D, shape: Container) => ClipFuncOutput, this>;
}
